#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main() {
    int ret = fork();

    if (ret == 0) {
        printf("parent PID before sleep is %d\n", getppid());
        sleep(5);
    } else {
        printf("parent is done!\n");
        return 0;
    }

    printf("parent PID after sleep is %d\n", getppid());

    return 0;
}
