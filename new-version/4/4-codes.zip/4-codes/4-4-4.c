#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>

int main() {
	int ret = fork();
	if (ret == 0) {
		execlp("ls", "ls", "-g", "-h", NULL);
	} else {
		wait(NULL);
	}
	return 0;
}
