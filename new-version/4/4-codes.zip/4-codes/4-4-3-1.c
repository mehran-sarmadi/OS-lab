#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>

int main() {
    int ret = fork();

    if (ret == 0) {
        for (int i = 0; i < 100; i++) {
            printf("i: %d\n", i + 1);
        }
        exit(0);
    } else {
        wait(NULL);
        printf("finish.\n");
    }

    return 0;
}
