#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>

int main() {
	int ret = fork();
	printf("after first fork.\n");
	if (ret == 0) {
		return 23;
	} else {
		int rc = 0;
		wait(&rc);
		printf("return code is %d\n", WEXITSTATUS(rc));
	}
	fork();
	printf("after second fork.\n");
    fork();
	printf("after third fork.\n");
	return 0;
}
