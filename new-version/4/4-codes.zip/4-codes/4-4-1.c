#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main(){
    int self_pid = getpid();
    printf("pid: %d\n", self_pid);
    return 0;
}
