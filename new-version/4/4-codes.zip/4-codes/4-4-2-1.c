#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

int main(){
	int parent_pid = getppid();
	printf("parent pid: %d\n", parent_pid);
	return 0;
}
