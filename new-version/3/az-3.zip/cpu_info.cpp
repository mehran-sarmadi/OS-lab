#include <bits/stdc++.h>

using namespace std;

int main() {

    ifstream cpuinfo_filestream("/proc/cpuinfo");
    stringstream buffer;
    buffer << cpuinfo_filestream.rdbuf();
    string output = buffer.str();
    cpuinfo_filestream.close();

    std::regex model_name_regex("model name(\\s*): (.+)");
    std::smatch model_name_matches;
    if(std::regex_search(output, model_name_matches, model_name_regex)) {
        std::cout << "model name: " << model_name_matches[2].str() << "\n";
    }

    std::regex cpu_freq_regex("cpu MHz(\\s*): (.+)");
    std::smatch cpu_freq_matches;
    if(std::regex_search(output, cpu_freq_matches, cpu_freq_regex)) {
        std::cout << "cpu freq: " << cpu_freq_matches[2].str() << "\n";
    }

    std::regex cache_size_regex("cache size(\\s*): (.+) KB");
    std::smatch cache_size_matches;
    if(std::regex_search(output, cache_size_matches, cache_size_regex)) {
        std::cout << "cache size: " << cache_size_matches[2].str() << "\n";
    }

}
