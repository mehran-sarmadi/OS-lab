#include <bits/stdc++.h>

using namespace std;

int main() {

    ifstream meminfo_filestream("/proc/meminfo");
    stringstream buffer;
    buffer << meminfo_filestream.rdbuf();
    string output = buffer.str();
    meminfo_filestream.close();
    int mem_free, mem_total;

    std::regex mem_total_regex("MemTotal:(\\s*)(.+) kB");
    std::smatch mem_total_matches;
    if(std::regex_search(output, mem_total_matches, mem_total_regex)) {
        mem_total = stoi(mem_total_matches[2]);
        std::cout << "mem total: " << mem_total << "\n";
    }

    std::regex mem_free_regex("MemFree:(\\s*)(.+) kB");
    std::smatch mem_free_matches;
    if(std::regex_search(output, mem_free_matches, mem_free_regex)) {
        mem_free = stoi(mem_free_matches[2]);
        std::cout << "mem free: " << mem_free << "\n";
    }

    std::cout << "mem used: " << mem_total - mem_free << "\n";
}
