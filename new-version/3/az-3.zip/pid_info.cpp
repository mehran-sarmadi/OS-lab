#include <bits/stdc++.h>

using namespace std;

int main()
{
    string s;
    cin >> s;

    string cmd = "/proc/" + s + "/cmdline";
    ifstream cmd_stream(cmd);
    std::cout << cmd_stream.rdbuf();
    cmd_stream.close();

    string environ = "/proc/" + s + "/environ";
    ifstream environ_stream(environ);
    std::cout << environ_stream.rdbuf();
    environ_stream.close();

    string statm = "/proc/" + s + "/statm";
    ifstream statm_stream(statm);
    std::cout << statm_stream.rdbuf();
    statm_stream.close();

    string status = "/proc/" + s + "/status";
    ifstream status_stream(status);
    std::cout << status_stream.rdbuf();
    status_stream.close();

    return 0;
}